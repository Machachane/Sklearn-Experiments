# sklearn-experiments
 Experiments with sklearn and 20newsgroups
